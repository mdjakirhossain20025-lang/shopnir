const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
